import { Pipe, PipeTransform } from "@angular/core";
import { Ticket } from '../model/ticket.model';

@Pipe(
    {name:"SearchEmployeeId"}
)

export class SearchEmployeeId implements PipeTransform
{
    transform(tickets:Ticket[] , searchByEmployeeId: any) 
    {
        if(searchByEmployeeId == undefined)
        {
        
            return tickets;
        }

        return tickets.filter(function(tickets:Ticket)
        {
            console.log("All Tickets"+tickets);
            return tickets.ticketId.toLocaleString().includes(searchByEmployeeId.toLocaleString());
         
        })
    }

    
}


@Pipe(
    {name:"SearchCapgeminiId"}
)

export class SearchCapgeminiId implements PipeTransform
{
    transform(tickets:Ticket[] , searchByCapgeminiId: any) 
    {
        if(searchByCapgeminiId == undefined)
        {
        
            return tickets;
        }

        return tickets.filter(function(tickets:Ticket)
        {
            console.log("All Tickets"+tickets);
            return tickets.employee.capgeminiId.toPrecision().includes(searchByCapgeminiId.toLocaleString());
             
        })
    }

    
}


@Pipe(
    {name:"SearchStatus"}
)

export class SearchStatus implements PipeTransform
{
    transform(tickets:Ticket[] , searchStatus: any) 
    {
        if(searchStatus == undefined)
        {
        
            return tickets;
        }

        return tickets.filter(function(tickets:Ticket)
        {
            console.log("All Tickets"+tickets);
            return tickets.status.toLocaleLowerCase().includes(searchStatus.toLocaleString());
             
        })
    }

    
}

