export class Admin{
    public empId:number;
    public capgeminiId:number;
    public name:string;
    public email:string;
    public password:string;
}