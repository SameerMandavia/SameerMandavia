export class Login{
    public capgeminiId:string;
    public password:string;
}