package com.cg.capcafe.service;

import java.util.List;
import com.cg.capcafe.dto.Order;
import com.cg.capcafe.dto.Transaction;
import com.cg.capcafe.exception.TransactionNotFoundException;

public interface ITransactionService 
{
	/**
	 * Method for get total Amount.
	 * @param transaction
	 * @return total amount.
	 * @throws TransactionNotFoundException
	 */
	public Transaction getTotalAmount(Transaction transaction)throws TransactionNotFoundException;
	
	/**
	 * Method for Add Transaction or payment.
	 * @param transaction
	 * @return Transaction.
	 * @throws TransactionNotFoundException
	 */
	public Transaction addTransaction(Transaction transaction)throws TransactionNotFoundException;
	
	/**
	 * Method for get transaction using order Id.
	 * @param orderId
	 * @return order.
	 * @throws TransactionNotFoundException
	 */
	public Order getTransactionById(int orderId)throws TransactionNotFoundException;
	
	/**
	 * Method for get All Transaction.
	 * @return List of Transactions.
	 * @throws TransactionNotFoundException
	 */
	public List<Transaction> getAllTransaction()throws TransactionNotFoundException; 
}
