package com.cg.capcafe.controller;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.cg.capcafe.dto.Employee;
import com.cg.capcafe.dto.Order;
import com.cg.capcafe.dto.Ticket;
import com.cg.capcafe.dto.Transaction;
import com.cg.capcafe.exception.EmployeeNotFoundException;
import com.cg.capcafe.exception.TicketNotFoundException;
import com.cg.capcafe.exception.TransactionNotFoundException;
import com.cg.capcafe.service.TicketCrudServiceImpl;
import com.cg.capcafe.service.TransactionServiceImpl;

/**
 * @author Sameer Mandavia
 *
 */
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class TicketController 
{

	@Autowired
	TicketCrudServiceImpl ticketService;
	
	@Autowired
	TransactionServiceImpl transactionService;
	
	/********************************* Ticket Part *************************************************************/

	
	/**
	 * Getmapping used to get all the tickets.
	 * method name = getAllQueires()
	 * Description = Gives all the Queries to Admin. 
	 * @return = List of Tickets which is raised by the employees.
	 * @throws TicketNotFoundException
	 * */
	@GetMapping(value="/getAllQueries")
	public List<Ticket> getAllQueries()throws TicketNotFoundException
	{
		List<Ticket> allTickets = ticketService.getAllQueries();
		return allTickets;
	}
	
	
	/**
	 * Getmapping used to get the single query.
	 * Description :- Method used for getting single Query using tickteTd.
	 * @param ticketId
	 * @return single Query
	 * @throws TicketNotFoundException
	 * 
	 * */
	@GetMapping(value="/getSingleQuery/{ticketId}")
	public Ticket getSingleQuery(@PathVariable int ticketId)throws TicketNotFoundException
	{
		
		return ticketService.getSingleQuery(ticketId);
	}
	
	
	/**
	 * Post mapping used for send the response and add in the table.
	 * @param ticket
	 * @return response of ticket solved or not.
	 * @throws TicketNotFoundException
	 * 
	 */
	@PostMapping(value="/sendResponse")
	public Ticket sendResponse(@RequestBody Ticket ticket) throws TicketNotFoundException
	{
		return ticketService.sendResponse(ticket);
	}

	
	
	
	/**
	 * post mapping used for add Employee
	 * method name = addEmployee
	 * Description = Using this the Employee will be added.
	 */
	@PostMapping(value="/addEmployee")
	public Employee addEmployee(@RequestBody Employee employee) throws EmployeeNotFoundException
	{
		return ticketService.addEmployee(employee);
	}
	

	
	/********************************* Ticket Raised Part *************************************************************/

	
	/**
	 * Post mapping used for add the raised ticket by the Employee.
	 * method name:-RaiseTicket is a user part .When the user has to raise ticket User will goes to help desk tab and with the help of 
	 * this method the ticket submit and it will solved by Admin.   
	 * @param ticket
	 * @return Ticket
	 */
	@PostMapping(value="/userRaiseTicket")
	public Ticket raiseTicket(@RequestBody Ticket ticket)
	{
		return ticketService.raiseTicket(ticket);
	}
	
	
	/********************************* Ticket raised *************************************************************/

	
	
	/**
	 * Get mapping used for get the total amount of orders. 
	 * @param transaction
	 * @return Total Amount
	 */
	@PostMapping(value="/getTotalAmount")
	public Transaction  getTotalAmount(@RequestBody Transaction transaction) throws EmployeeNotFoundException
	{
		System.out.println("controller");
		return transactionService.getTotalAmount(transaction);
		
	}
	
	
	/**
	 * Post mapping used for payment. 
	 * @param transaction
	 * @return Transaction
	 */
	//localhost:9999/payment
	@PostMapping(value="/addTransaction")
	public Transaction addTransaction(Transaction transaction) throws TransactionNotFoundException
	{
		System.out.println("payment");
		return transactionService.addTransaction(transaction);	
		
	}
	
	/**
	 * Get mapping used for get Transaction using orderId.
	 * @param orderId
	 * @return Order
	 */
	//localhost:9999/getTransactionById/{empId}
	@GetMapping(value="/getTransactionById/{orderId}")
	public Order getTransactionById(@PathVariable int orderId) 
	{
		return transactionService.getTransactionById(orderId);
		
	}
	
	/**
	 * Get mapping used for get All Transactions.
	 * @return list of Transactions.
	 */
	//localhost:9999/getAllTransactions
	@GetMapping(value="/getAllTransactions")
	public List<Transaction> getAllTransaction() 
	{
		return transactionService.getAllTransaction();
		
	}
	
	 

}
