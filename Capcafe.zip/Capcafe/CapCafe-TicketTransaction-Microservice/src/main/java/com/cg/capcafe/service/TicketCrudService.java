package com.cg.capcafe.service;

import java.util.List;
import com.cg.capcafe.dto.Employee;
import com.cg.capcafe.dto.Ticket;
import com.cg.capcafe.exception.EmployeeNotFoundException;
import com.cg.capcafe.exception.TicketNotFoundException;

/**
 * Interface Name:- TicketCrudService
 * Description:- Has Three methods getAllQuery(),getSingleQuery(),sendResponse().
 * */

public interface TicketCrudService
{

	/**
	 * Method for get all Queries which is raised by Employees.
	 * @return list of Tickets.
	 * @throws TicketNotFoundException
	 */
	public List<Ticket> getAllQueries()throws TicketNotFoundException;		//Using this we get all the Employees raised Queries.
	
	//public Ticket getSingleQuery(int empId);	//We get Query of a particular Employee.
	
	/**
	 * Method for get a single query of Employee.
	 * @param ticketId.
	 * @return Ticket.
	 * @throws TicketNotFoundException.
	 * 
	 */
	public Ticket getSingleQuery(int ticketId)throws TicketNotFoundException;
	
	/**
	 * Method for Send response to the specific Employee whose raised that ticket.
	 * @param ticket.
	 * @return Ticket.
	 * @throws TicketNotFoundException.
	 * 
	 */
	
	public Ticket sendResponse(Ticket ticket)throws TicketNotFoundException;	//It will send the solution to the employee and change the status.
	
	
	
	/**
	 * Method for get a single query of Employee.
	 * @param ticketId.
	 * @return Ticket.
	 * @throws TicketNotFoundException.
	 * 
	 */
//	public Ticket getTicket(int ticketId)throws TicketNotFoundException;
	
	
	
	/**
	 * Method for Add Employee.
	 * @param employee.
	 * @return Employee.
	 * @throws EmployeeNotFoundException.
	 * 
	 */
	public Employee addEmployee(Employee employee)throws EmployeeNotFoundException; // For Dummy data
	
	
	/**
	 * Method=  If Employee wants to complaint against any thing related to food ,app or etc.
	 * @param ticket.
	 * @return Ticket.
	 * @throws TicketNotFoundException.
	 * 
	 */
	public Ticket raiseTicket(Ticket ticket)throws TicketNotFoundException;
	
	//public Ticket getSingleTicket_Of_Employee(int empId, int ticketId); 
	
	//public String raised(int empId,String query);

}

