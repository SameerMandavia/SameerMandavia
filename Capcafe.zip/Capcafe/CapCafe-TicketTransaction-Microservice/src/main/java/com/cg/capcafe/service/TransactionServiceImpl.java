package com.cg.capcafe.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.capcafe.dto.Order;
import com.cg.capcafe.dto.Transaction;
import com.cg.capcafe.exception.EmployeeNotFoundException;
import com.cg.capcafe.exception.TransactionNotFoundException;
import com.cg.capcafe.repository.CafeRepository;
import com.cg.capcafe.repository.EmployeeRepository;
import com.cg.capcafe.repository.OrderRepository;
import com.cg.capcafe.repository.TransactionRepository;

@Service
@Transactional
public class TransactionServiceImpl implements ITransactionService {
	@Autowired
	TransactionRepository transactionRepository;

	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	OrderRepository orderRepository;

	@Autowired
	CafeRepository cafeRepository;

	@Override
	public Transaction getTotalAmount(Transaction transaction) throws TransactionNotFoundException {

		double wallet;

		int empId = transaction.getOrder().getEmployee().getEmpId();
		int cafeId = transaction.getOrder().getCafe().getCafeId();
		wallet = transaction.getOrder().getEmployee().getWallet();
		double totalAmount = transaction.getOrder().getTotalAmount();
		double cafe_account = transaction.getOrder().getCafe().getAccount();
		if (wallet <= 0) {
			throw new EmployeeNotFoundException("Insuffiecient Amount");
		} else if (wallet < totalAmount) {
			throw new EmployeeNotFoundException("Insuffiecient Amount");
		} else if (wallet >= totalAmount) {
			wallet = wallet - totalAmount; // assign the wallet amount.
			cafe_account = cafe_account + totalAmount; // assign the totalAmount to Cafe account.
			employeeRepository.updateWallet(wallet, empId);
			cafeRepository.updateCafeAccount(cafe_account, cafeId);
		}
		return transaction;
	}

	@Override
	public Transaction addTransaction(Transaction transaction) {
		if (transaction == null) {
			throw new TransactionNotFoundException("Transaction not found");
		}
		transaction.setPaymentMode("Wallet");
		transaction.setTimestamp(LocalDateTime.now());
		return transactionRepository.save(transaction);
	}

	@Override
	public Order getTransactionById(int orderId) {
		Optional<Order> orders = orderRepository.findById(orderId);
		if (!orders.isPresent()) {
			throw new TransactionNotFoundException("Transaction not found with Order Id: " + orderId);
		}
		return orders.get();
	}

	@Override
	public List<Transaction> getAllTransaction() {
		List<Transaction> allTransaction = transactionRepository.findAll();
		if (allTransaction.isEmpty()) {
			throw new TransactionNotFoundException("No transaction found");
		}
		return allTransaction;
	}

}
