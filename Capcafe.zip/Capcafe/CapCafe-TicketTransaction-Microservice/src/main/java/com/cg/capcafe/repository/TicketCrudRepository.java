package com.cg.capcafe.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.cg.capcafe.dto.Ticket;

/**
 * 
 * Interface Name:- TicketCrudRepository
 * 
 * */
/**
 * @author Sameer Mandavia Interface Name:- TicketCrudRepository Description :-
 *         TicketCrudRepository implements JpaRepository.
 */

@Repository
public interface TicketCrudRepository extends JpaRepository<Ticket, Integer> {
	@Query("SELECT t FROM Ticket t JOIN FETCH t.employee e WHERE e.empId=:empId")
	List<Ticket> getByEmpId(int empId);

	@Query("SELECT t FROM Ticket t")
	List<Ticket> findAllTicket();

}
