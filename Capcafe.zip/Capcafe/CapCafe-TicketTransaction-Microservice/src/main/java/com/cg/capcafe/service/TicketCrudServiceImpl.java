package com.cg.capcafe.service;

/**
 * Class Name:- TicketCrudServiceImpl.java
 * Description:- Has Three implemented methods getAllQuery(),getSingleQuery(),sendResponse().
 * */

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.capcafe.dto.Employee;
import com.cg.capcafe.dto.Ticket;
import com.cg.capcafe.dto.TicketStatus;
import com.cg.capcafe.exception.TicketNotFoundException;
import com.cg.capcafe.repository.EmployeeRepository;
import com.cg.capcafe.repository.OrderRepository;
import com.cg.capcafe.repository.TicketCrudRepository;

@Service
@Transactional
public class TicketCrudServiceImpl implements TicketCrudService {

	@Autowired
	TicketCrudRepository ticketRepository;

	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	OrderRepository orderRepository;

	/**
	 * 
	 * method name:- getAllQueries Description:- It will gives all the queries to
	 * the Admin.
	 * 
	 */
	@Override
	public List<Ticket> getAllQueries() {
		return ticketRepository.findAll().stream().map(ticket -> {
			if (ticket.getEmployee() != null) {
				ticket.getEmployee().setTicketsRaised(null);
				return ticket;
			} else {
				return ticket;
			}
		}).collect(Collectors.toList());
	}

	/**
	 * 
	 * method name:- getSingleQuery Description:- It will gives a particular
	 * Employee query to the Admin.
	 * 
	 */

	public static <T> List<T> convertSetToList(Set<T> set) {

		List<T> list = new ArrayList<>();
		for (T t : set)
			list.add(t);
		return list;
	}

	@Override
	public Ticket getSingleQuery(int ticketId) {
		Ticket tickets = ticketRepository.findById(ticketId).get();
		System.out.println("hello");
		if (tickets == null) {
			throw new TicketNotFoundException("Ticket with Id:" + ticketId + "  not found.");
		}
		tickets.getEmployee().setTicketsRaised(null);
		System.out.println(tickets);
		return tickets;
	}

	/**
	 * 
	 * method name:- sendResponse Description:- It will send the response(Solution)
	 * to the Employee.
	 * 
	 */
	@Override
	public Ticket sendResponse(Ticket ticket) {
		ticket.setStatus(TicketStatus.RESOLVED);
		System.out.println(ticket);
		return ticketRepository.save(ticket);
	}

	/**
	 * 
	 * method name:- addEmployee Description:- It will add the Employee.
	 * 
	 */
	@Override
	public Employee addEmployee(Employee employee) {
		if (employee != null) {
			return employeeRepository.save(employee);
		} else {
			throw new TicketNotFoundException("Invalid Details");
		}
	}

	@Override
	public Ticket raiseTicket(Ticket ticket) {
		ticket.setStatus(TicketStatus.UNRESOLVED);
		return ticketRepository.save(ticket);
	}

}
