package capcafe;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.assertj.core.api.Assertions.assertThat;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.cg.capcafe.controller.TicketController;
import com.cg.capcafe.dto.Employee;
import com.cg.capcafe.dto.Ticket;
import com.cg.capcafe.dto.TicketStatus;
import com.cg.capcafe.exception.TicketNotFoundException;
import com.cg.capcafe.service.TicketCrudServiceImpl;


//@WebMvcTest(TicketController.class)
@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes=TicketController.class)
public class HelpDeskControllerTesting {

	@InjectMocks
	TicketController ticketController;
	
	
	private MockMvc mvc;
	
	@MockBean
	TicketCrudServiceImpl ticketService;
	
	@Before
	public void setUp() {
		mvc = MockMvcBuilders.standaloneSetup(ticketController).build();
	}
	
	
	
	@Test
	public void getAllQueries() throws Exception
	{
        
        Employee mockEmp = new Employee(1, 183381, "s@g.com", "sameer", 160, null, null, "Sameer Mandavia", "male",
				null, null);

		List<Ticket> tickets = new ArrayList<Ticket>();

		Ticket t1 = new Ticket(1, "Menu not displayed", mockEmp, "Restart it", TicketStatus.RESOLVED);
		Ticket t2 = new Ticket(2, "Orders not displayed", mockEmp, "", TicketStatus.UNRESOLVED);

		tickets.add(t1);
		tickets.add(t2);
		Mockito.when(ticketService.getAllQueries()).thenReturn(tickets);
		
		mvc.perform(MockMvcRequestBuilders.get("/getAllQueries"))
		.andExpect(status().isOk());

        
	}

}
