package capcafe;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;

import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;


import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.capcafe.dto.Employee;
import com.cg.capcafe.dto.Ticket;
import com.cg.capcafe.dto.TicketStatus;

import com.cg.capcafe.repository.TicketCrudRepository;
import com.cg.capcafe.repository.TransactionRepository;
import com.cg.capcafe.service.TicketCrudServiceImpl;
import com.cg.capcafe.service.TransactionServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TicketCrudServiceImpl.class)
public class HelpDeskServiceTesting {

	@MockBean
	TicketCrudRepository ticketRepoMock;
	@MockBean
	TransactionRepository transactionRepoMock;
	@MockBean
	TicketCrudServiceImpl ticketService;
	@MockBean
	TransactionServiceImpl transactionService;
	
	@Rule
    public ExpectedException thrown = ExpectedException.none();

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	// @Test
	// public void check() {
	// Employee
	// mockEmp = new Employee(1, 183381, "s@g.com", "sameer", 160, null, null,
	// "Sameer Mandavia", "male",null, null);
	// Ticket t = new Ticket(2,"Orders not displayed",
	// mockEmp,"",TicketStatus.UNRESOLVED);
	//
	// Ticket ticket=ticketService.getSingleQuery(2);
	// System.out.println(ticket);
	// assertEquals(t, ticket);
	// }

	@Test()
	public void getAllQueriesTest() {
		Employee mockEmp = new Employee(1, 183381, "s@g.com", "sameer", 160, null, null, "Sameer Mandavia", "male",
				null, null);

		List<Ticket> tickets = new ArrayList<Ticket>();

		Ticket t1 = new Ticket(1, "Menu not displayed", mockEmp, "Restart it", TicketStatus.RESOLVED);
		Ticket t2 = new Ticket(2, "Orders not displayed", mockEmp, "", TicketStatus.UNRESOLVED);

		tickets.add(t1);
		tickets.add(t2);

		Mockito.when(ticketService.getAllQueries()).thenReturn(tickets);

		assertEquals(2, ticketService.getAllQueries().size());

	}

	@Test()
	public void getNotAllQueriesTest() {
		Employee mockEmp = new Employee(1, 183381, "s@g.com", "sameer", 160, null, null, "Sameer Mandavia", "male",
				null, null);

		List<Ticket> tickets = new ArrayList<Ticket>();

		Ticket t1 = new Ticket(1, "Menu not displayed", mockEmp, "Restart it", TicketStatus.RESOLVED);
		Ticket t2 = new Ticket(2, "Orders not displayed", mockEmp, "", TicketStatus.UNRESOLVED);
		Ticket t3 = new Ticket(3, "Price not displayed", mockEmp, "", TicketStatus.UNRESOLVED);

		tickets.add(t1);
		tickets.add(t2);
		tickets.add(t3);

		Mockito.when(ticketService.getAllQueries()).thenReturn(tickets);

		assertNotEquals(2, ticketService.getAllQueries().size());

	}
	
	
	@Test
	public void getSingleQuery() {
		Employee mockEmp = new Employee(1, 183381, "s@g.com", "sameer", 160, null, null, "Sameer Mandavia", "male",
				null, null);

		Mockito.when(ticketService.getSingleQuery(1))
				.thenReturn(new Ticket(1, "Menu not displayed", mockEmp, "Restart it", TicketStatus.RESOLVED));

		Ticket singleTicket = ticketService.getSingleQuery(1);

		assertEquals(singleTicket, ticketService.getSingleQuery(1));

	}

	@Test
	public void getNotSingleQuery() {
		Employee mockEmp = new Employee(1, 183381, "s@g.com", "sameer", 160, null, null, "Sameer Mandavia", "male",
				null, null);

		Mockito.when(ticketService.getSingleQuery(2))
				.thenReturn(new Ticket(2, "Menu not displayed", mockEmp, "Restart it", TicketStatus.RESOLVED));

		Ticket singleTicket = ticketService.getSingleQuery(1);

		assertNotEquals(singleTicket, ticketService.getSingleQuery(2));
		

	}
	
	
//	@Test(expected=TicketNotFoundException.class)
//	public void getSingleQueryThrownException() {
//		int ticketId = 1;
//		thrown.expect(TicketNotFoundException.class);
//		thrown.expectMessage(containsString("Ticket with Id:"+ticketId+"  not found."));
//		
//		Employee mockEmp = new Employee(1, 183381, "s@g.com", "sameer", 160, null, null, "Sameer Mandavia", "male",
//				null, null);
//		Mockito.when(ticketService.getSingleQuery(1))
//				.thenReturn(new Ticket(1, "Menu not displayed", mockEmp, "", TicketStatus.UNRESOLVED));
//		
//
//	}
	
	
	@Test
	public void raisedTicket() {
		Employee mockEmp = new Employee(1, 183381, "s@g.com", "sameer", 160, null, null, "Sameer Mandavia", "male",
				null, null);

		Ticket raisedTicket = new Ticket(1, "Menu not displayed", mockEmp, "", TicketStatus.UNRESOLVED);
		Mockito.when(ticketService.raiseTicket(raisedTicket))
				.thenReturn(new Ticket(1, "Menu not displayed", mockEmp, "", TicketStatus.UNRESOLVED));

		assertEquals(raisedTicket, ticketService.raiseTicket(raisedTicket));
	}

	@Test
	public void sendResponse() {

		Employee mockEmp = new Employee(1, 183381, "s@g.com", "sameer", 160, null, null, "Sameer Mandavia", "male",
				null, null);

		Ticket unResolved = new Ticket(1, "Menu not displayed", mockEmp, "", TicketStatus.UNRESOLVED);
		Ticket Resolved = new Ticket(1, "Menu not displayed", mockEmp, "Restart it", TicketStatus.RESOLVED);
		Mockito.when(ticketService.sendResponse(unResolved))
				.thenReturn(new Ticket(1, "Menu not displayed", mockEmp, "Restart it", TicketStatus.RESOLVED));

		assertEquals(Resolved, ticketService.sendResponse(unResolved));

	}
}
