package capcafe;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import com.cg.capcafe.dto.Employee;
import com.cg.capcafe.dto.Order;
import com.cg.capcafe.dto.Transaction;
import com.cg.capcafe.exception.TransactionNotFoundException;
import com.cg.capcafe.service.TransactionServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TransactionServiceImpl.class)
public class TransactionServiceTesting {

	@MockBean
	TransactionServiceImpl transactionService;

	@Test
	public void addTransaction() throws TransactionNotFoundException {
		Employee employee = new Employee(1, 183381, "s@g.com", "sameer", 160, null, null, "Sameer Mandavia", "male",
				null, null);
		// Cafe cafe = new Cafe(cafeId, name, location, owner, account, avgRating,
		// avgPrice, reviews, menu);
		Order order = new Order(1, 160, null, employee, null, LocalDateTime.now());
		Transaction transaction = new Transaction(1, order, "Wallet", LocalDateTime.now());

		Mockito.when(transactionService.addTransaction(transaction)).thenReturn(transaction);
		assertEquals(transaction, transactionService.addTransaction(transaction));
	}

	@Test
	public void getTransactionById() {
		Employee employee = new Employee(1, 183381, "s@g.com", "sameer", 160, null, null, "Sameer Mandavia", "male",
				null, null);
		// Cafe cafe = new Cafe(cafeId, name, location, owner, account, avgRating,
		// avgPrice, reviews, menu);
		Order order = new Order(1, 160, null, employee, null, LocalDateTime.now());
		Transaction transaction = new Transaction(1, order, "Wallet", LocalDateTime.now());

		Mockito.when(transactionService.getTransactionById(1)).thenReturn(order);
		assertEquals(order, transactionService.getTransactionById(1));

	}

	@Test
	public void enterWrongTransactionById() {
		Employee employee = new Employee(1, 183381, "s@g.com", "sameer", 160, null, null, "Sameer Mandavia", "male",
				null, null);
		// Cafe cafe = new Cafe(cafeId, name, location, owner, account, avgRating,
		// avgPrice, reviews, menu);
		Order order = new Order(1, 160, null, employee, null, LocalDateTime.now());
		Transaction transaction = new Transaction(1, order, "Wallet", LocalDateTime.now());

		Mockito.when(transactionService.getTransactionById(1)).thenReturn(order);
		assertNotEquals(order, transactionService.getTransactionById(2));

	}

	@Test
	public void getAllTransaction() {
		Employee employee = new Employee(1, 183381, "s@g.com", "sameer", 160, null, null, "Sameer Mandavia", "male",
				null, null);
		// Cafe cafe = new Cafe(cafeId, name, location, owner, account, avgRating,
		// avgPrice, reviews, menu);
		Order order = new Order(1, 160, null, employee, null, LocalDateTime.now());
		Transaction transaction1 = new Transaction(1, order, "Wallet", LocalDateTime.now());
		Transaction transaction2 = new Transaction(2, order, "Wallet", LocalDateTime.now());

		List<Transaction> transactionList = new ArrayList<>();

		transactionList.add(transaction1);
		transactionList.add(transaction2);

		Mockito.when(transactionService.getAllTransaction()).thenReturn(transactionList);
		assertEquals(2, transactionService.getAllTransaction().size());

	}

	@Test
	public void getNotAllTransaction() {
		Employee employee = new Employee(1, 183381, "s@g.com", "sameer", 160, null, null, "Sameer Mandavia", "male",
				null, null);
		// Cafe cafe = new Cafe(cafeId, name, location, owner, account, avgRating,
		// avgPrice, reviews, menu);
		Order order = new Order(1, 160, null, employee, null, LocalDateTime.now());
		Transaction transaction1 = new Transaction(1, order, "Wallet", LocalDateTime.now());
		Transaction transaction2 = new Transaction(2, order, "Wallet", LocalDateTime.now());

		List<Transaction> transactionList = new ArrayList<>();

		transactionList.add(transaction1);
		transactionList.add(transaction2);

		Mockito.when(transactionService.getAllTransaction()).thenReturn(transactionList);
		assertNotEquals(3, transactionService.getAllTransaction().size());

	}

}
