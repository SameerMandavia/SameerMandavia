package com.cg.capacfe.dto;

public enum TicketStatus {
	UNRESOLVED,
	RESOLVED
}
