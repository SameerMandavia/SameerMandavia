package com.cg.capacfe.dto;

public enum ItemType {
	VEG,
	NON_VEG
}
