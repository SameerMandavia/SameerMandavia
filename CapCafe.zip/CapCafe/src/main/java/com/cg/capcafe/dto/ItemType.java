package com.cg.capcafe.dto;

public enum ItemType {
	VEG,
	NON_VEG
}
