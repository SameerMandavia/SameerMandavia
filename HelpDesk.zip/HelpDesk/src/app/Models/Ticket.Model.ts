import { Employee } from "./Employee.Model";
import { TicketStatus } from "./TicketStatus.Model";
import { Review } from "./Review.Model";
import { Order } from "./Order.Model";


export class Ticket
{
    public ticketId: number;
    public query : string;
    public employee : Employee;
    public response : string;
    public status : TicketStatus;
}