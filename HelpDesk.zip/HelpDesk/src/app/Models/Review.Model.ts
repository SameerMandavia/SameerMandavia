export class Review
{
    public reviewId : number;
    public cafeId : number;
    public rating : number;
    public employeeId : number;
    public review : string;
}   