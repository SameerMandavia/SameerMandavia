export enum TicketStatus
{
    UNRESOLVED,
    RESOLVED 
}