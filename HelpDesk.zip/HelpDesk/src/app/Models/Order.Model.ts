import { Employee } from "./Employee.Model";
import { Cafe } from "./Cafe.Model";
import { FoodItem } from "./FoodItem.Model";


export class Order
{
    public orderId : number;
    public totalAmount : number;
    public cafe : Cafe;
    public employee : Employee;
    public cart : FoodItem;
    public timestamp : string;
    

    
}