import { Order } from "./Order.Model";

export class Transaction
{
   public transactionId : number;
   public order : Order;
   public paymentMode : string;
   public timestamp : string;
}