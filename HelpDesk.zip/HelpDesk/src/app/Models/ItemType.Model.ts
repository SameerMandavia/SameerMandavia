export enum ItemType
{
    VEG ,
    Non_VEG 
}