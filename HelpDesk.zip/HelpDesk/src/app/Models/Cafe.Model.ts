import { Review } from "./Review.Model";
import { FoodItem } from "./FoodItem.Model";


export class Cafe
{
    public cafeId : number;
    public name : string;
    public location : string;
    public owner : string;
    public cuisine : string;
    public account : number;
    public avgRating : number;
    public avgPrice : number;
    public reviews:Review;
    public menu:FoodItem;    
}