
import { Order } from "./Order.Model";
import { Cafe } from "./Cafe.Model";


export class FoodItem
{
    public itemId : number;
    public itemType : string;
    public name : string;
    public price : number;
    public orders:Order;
    public cafe:Cafe;

    
}