import { Ticket } from "./Ticket.Model";
import { Review } from "./Review.Model";
import { Order } from "./Order.Model";


export class Employee
{
    public empId : number;
    public capgeminiId : number;
    public email : string;
    public password : string;
    public wallet : number;
    public pastReviews:Review;
    public pastOrders:Order;
    public name : string;
    public gender : string;
    public subscriptionDate:string;
    public ticketsRaised:Ticket;

}