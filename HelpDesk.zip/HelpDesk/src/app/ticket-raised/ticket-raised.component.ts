import { Component, OnInit } from '@angular/core';
import { TicketService } from '../Services/ticket-raised.service';
import { Router } from '@angular/router';
import { Ticket } from '../Models/Ticket.Model';
import { Employee } from '../Models/Employee.Model';

@Component({
  selector: 'app-ticket-raised',
  templateUrl: './ticket-raised.component.html',
  styleUrls: ['./ticket-raised.component.css'],
  providers:[TicketService]
})
export class TicketRaisedComponent implements OnInit 
{

     tickets : Ticket[];
     employee : Employee[]
    singleEmpQuery : any;
  constructor(public route:Router,private ticketService:TicketService) 
  {
      

   }

  ngOnInit() 
  {
    this.getAllQueries()
  }

  back()
  {
    this.route.navigate(['/adminDashboard'])
  }

  getSingleTicket(ticketId:number)
  {
    
     /* this.ticketService.getSingleQuery(ticketId).subscribe
     ((singleQuery)=>console.log(this.singleEmpQuery = singleQuery,"single")) */
    this.route.navigate(['/Query/'+ticketId])
  }

  getAllQueries()
  {
    this.ticketService.getAllQueries().subscribe
    ((data)=>console.log(this.tickets = data))
    
  }


}
