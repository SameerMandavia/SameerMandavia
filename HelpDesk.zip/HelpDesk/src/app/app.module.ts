﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { TicketRaisedComponent } from './ticket-raised/ticket-raised.component';
import { RouterModule,Routes } from "@angular/router";
import { TicketService } from './Services/ticket-raised.service';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { SingleTicketComponent } from './single-ticket/single-ticket.component'
import { HttpClientModule } from '@angular/common/http';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { UserDeskComponent } from './user-dashboard/user-desk.component';
import { UserHelpDeskComponent } from './user-help-desk/user-help-desk.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentService } from './Services/payment.service';
import { UserHelpDeskService } from './Services/user-help-desk.service';

const routes : Routes = [

    {path:'',redirectTo:'/adminDashboard',pathMatch:'full'},
    {path:'adminDashboard',component:AdminDashboardComponent},
    {path:'ticket',component:TicketRaisedComponent},
    {path:'Query/:ticketId',component:SingleTicketComponent},
    {path:'userDashboard',component:UserDeskComponent},
    {path:'RaisedQuery',component:UserHelpDeskComponent},
    {path:'payment',component:PaymentComponent}
]


@NgModule({
    imports: [
        BrowserModule,
        HttpClientModule,
        RouterModule.forRoot(routes),
        FormsModule,
        ReactiveFormsModule,
        
    ],
    declarations: 
    [
        AppComponent,
        AdminDashboardComponent,
        TicketRaisedComponent,
        SingleTicketComponent ,
        UserDeskComponent ,
        UserHelpDeskComponent ,
        PaymentComponent     
    ],


    providers: 
    [
        TicketService,
        PaymentService,
        UserHelpDeskService
    ],
    
    bootstrap: [AppComponent]
})

export class AppModule { }