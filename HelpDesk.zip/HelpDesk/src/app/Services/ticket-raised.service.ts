import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Ticket } from "../Models/Ticket.Model";



@Injectable()
export class TicketService {
   
   constructor(private http : HttpClient) {}

    private GET_ALL_QUERIES = "http://localhost:9999/getAllQueries";
    private GET_SINGLE_QUERY_TICKETID = "http://localhost:9999/getSingleQuery/";

    getAllQueries():any
    {
        return this.http.get(this.GET_ALL_QUERIES);
    }

    getSingleQuery(ticketId:number)
    {
        return this.http.get<Ticket>(this.GET_SINGLE_QUERY_TICKETID+"/"+ticketId);
    }
}
