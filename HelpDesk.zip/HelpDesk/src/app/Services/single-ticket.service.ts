import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Ticket } from "../Models/Ticket.Model";



@Injectable()
export class SingleTicketService 
{
    ticketId : number
   solution : string
   constructor(private http : HttpClient) 
   {

    }

    private ADMIN_SEND_RESPONSE = "http://localhost:9999/sendResponse";

    // getSingleQuery(ticketId:number)
    // {
    //     return this.http.get('http://localhost:9999/getSingleQuery/'+ticketId).pipe(filter((data:Ticket)=>data.ticketId==ticketId  ))
    // }


    sendResponse(ticket:Ticket)
    {   
        return this.http.post(this.ADMIN_SEND_RESPONSE,ticket)
    }

}