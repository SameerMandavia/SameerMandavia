import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Employee } from "../Models/Employee.Model";
import { Ticket } from "../Models/Ticket.Model";
import { Observable } from "rxjs";




@Injectable()
export class UserHelpDeskService {
   
     private employee:Employee;


   constructor(private http : HttpClient) {}

    private USER_COMPLAINT_RAISED = "http://localhost:9999/userRaiseTicket";



    complaintRaised(ticket:Ticket):Observable<Ticket>
    {

           return this.http.post<Ticket>(this.USER_COMPLAINT_RAISED, ticket);
    }


}