import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { filter } from "rxjs/operators";
import { Ticket } from "../Models/Ticket.Model";
import { Employee } from "../Models/Employee.Model";
import { Order } from "../Models/Order.Model";
import { Transaction } from "../Models/Transaction.Model";
import { Observable } from "rxjs";



@Injectable()
export class PaymentService 
{
   
   constructor(private http : HttpClient) {}

    private EMPLOYEE_DETAILS = "http://localhost:9999/payment";
   // private ORDER_DETAILS = "http://localhost:9999/order";

   // paymentEmployee()
   // {
   //    return this.http.get<Employee>(this.EMPLOYEE_DETAILS);
   // }

   // paymentAmount()
   // {
   //    return this.http.get<Order>(this.ORDER_DETAILS);
   // }


   payment(transaction:Transaction):Observable<Transaction>
   {
      console.log(transaction);
      return this.http.post<Transaction>(this.EMPLOYEE_DETAILS,transaction)
      
   }


}