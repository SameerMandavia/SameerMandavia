import { Component, OnInit } from '@angular/core';
import { PaymentService } from '../Services/payment.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Employee } from '../Models/Employee.Model';
import { Order } from '../Models/Order.Model';
import { Transaction } from '../Models/Transaction.Model';
import { Cafe } from '../Models/Cafe.Model';
import { FoodItem } from '../Models/FoodItem.Model';
import { Review } from '../Models/Review.Model';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css'],
  providers:[PaymentService]
})
export class PaymentComponent implements OnInit 
{

    private employee : Employee;
    private order : Order;
    private transaction : Transaction;
    private cafe : Cafe;
    private cart : FoodItem;
    private review : Review;

    constructor(private paymentService : PaymentService ) 
    {
      this.employee = new Employee();
      this.order = new Order();
      this.transaction = new Transaction();
      this.cafe = new Cafe();
      this.cart = new FoodItem();
      this.review = new Review();
    }
    
    
    paymentForm : FormGroup;
  

  ngOnInit() 
  {
    this.paymentForm = new FormGroup
    ({
       empName: new FormControl(null,[Validators.required,Validators.pattern('^[a-zA-Z \-\']+')]),

       empId:new FormControl(null,[Validators.required,Validators.pattern('[0-9]*'),Validators.minLength(6),Validators.maxLength(6)])

    })  
  }


  paymentOrder()
{
    this.employee.empId=3;
    this.employee.capgeminiId=183382;
    this.employee.name="Jay Mandavia";
    this.employee.wallet=1000;
    
    //--------------------------employee----------------------------

    this.cafe.cafeId = 1;
    this.cafe.name="Backnshake";
    this.cafe.avgRating=4;
    this.cafe.owner="Nikhil";
    this.cafe.account=200;
    this.cafe.avgPrice=100;
    this.cafe.cuisine="Food";
    this.cafe.location="Pune";
    this.cafe.menu = this.cart;
    this.cafe.reviews = this.review;
    //------------------------cafe---------------------------------
    
    this.cart.itemId=1;
    this.cart.cafe= this.cafe;
    this.cart.itemType="VEG";
    this.cart.name="Cake";
    this.cart.price=20;
    this.cart.orders=this.order;

    //------------------------Cart----------------------------------
    this.review.rating=4;
    this.review.reviewId=1;
    this.review.cafeId=this.cafe.cafeId;
    this.review.employeeId=this.employee.empId;
    
    
    //-----------------------reviews--------------------------------
    
    
    this.order.orderId=1;
    this.order.employee = this.employee;
    this.order.cafe = this.cafe;
    this.order.cart = this.cart;
    this.order.timestamp = "2020-05-15 00:00:00";
    this.order.totalAmount = 20;
    
    //-----------------------order----------------------------------
    
    
    this.transaction.transactionId=1;
    this.transaction.order = this.order;
    this.transaction.paymentMode="Wallet";
    this.transaction.timestamp="2020-05-15 00:00:00";
    

    // JSON.stringify(this.transaction);

    

  
  this.paymentService.payment(this.transaction).subscribe
  (empPayment => {console.log(this.transaction = empPayment,"payment")})

   alert("Payment successfull");
}


}
