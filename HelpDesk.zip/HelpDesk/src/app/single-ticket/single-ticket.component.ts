import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { TicketService } from '../Services/Ticket-raised.service';
import { Ticket } from '../Models/Ticket.Model';
import { Router, ActivatedRoute } from '@angular/router';
import { SingleTicketService } from '../Services/single-ticket.service';

import { Observable } from 'rxjs';
import { Employee } from '../Models/Employee.Model';


@Component({
  selector: 'app-single-ticket',
  templateUrl: './single-ticket.component.html',
  styleUrls: ['./single-ticket.component.css'],
  providers:[TicketService,SingleTicketService]
})
export class SingleTicketComponent implements OnInit 
{

  private ticket : Ticket;
  private emp :Employee;

  constructor(private ticketService : TicketService,public route :Router,public activateRoute:ActivatedRoute,private singleTicketService:SingleTicketService ) 
  {
      this.ticket = new Ticket();
      this.emp = new Employee();
   }

  singleTicket_form : FormGroup
  singleEmpQuery : any ;
  ticketId : number;
  employeeQuery: Observable<Ticket>;



  ngOnInit() 
  {
    
    this.singleTicket_form = new FormGroup
    ({
      solution : new FormControl(null,[Validators.required,Validators.pattern('^[a-zA-Z \-\']+')])
    })

      this.ticketId = this.activateRoute.snapshot.params["ticketId"]

      this.getSingleTicket(this.ticketId);
  }


  getSingleTicket(ticketId:number)
  {
     this.ticketService.getSingleQuery(ticketId).subscribe
     ((singleQuery)=>console.log(this.singleEmpQuery = singleQuery,"single"))
  }


  ticketSolved()
  {

    //  this.emp.empId=1;
    //  this.emp.name="Sameer Mandavia";
    //  this.emp.capgeminiId=183381;
    //  this.ticket.query = "Menu's not displayed";

     this.emp.empId=2;
     this.emp.name="Sameer Mandavia";
     this.emp.capgeminiId=183381;
     this.emp.gender="Male";
     this.emp.email="sameer@gmail.com";
     this.emp.password="sameer";
     this.emp.wallet=1000;
     this.emp.subscriptionDate="2019-10-20"
     this.ticket.query = "Orders not displayed";



        this.ticket.employee = this.emp;
        this.ticket.ticketId = this.ticketId;
        this.ticket.employee.empId = this.emp.empId;
        this.ticket.query = this.ticket.query;
        this.ticket.response = this.singleTicket_form.value.solution;
        console.log(this.singleTicket_form.value.solution,"Form_value");
        console.log(this.ticket,"Ticket")

        this.singleTicketService.sendResponse(this.ticket)
        .subscribe((solution)=>console.log(solution,"solution"));
          alert("Ticket Solved")
          this.route.navigate(['/ticket'])
  }


}
