import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TicketService } from '../Services/ticket-raised.service';
import { Ticket } from '../Models/Ticket.Model';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  tickets : Ticket[] ;

  constructor(public route : Router, private ticketService:TicketService) { }

  ngOnInit() 
  {

  }

 
  raiseTicket()
  {
     this.route.navigate(['/ticket'])
  
  }




}
