import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { Order } from '../Models/Order.Model';
import { Ticket } from '../Models/Ticket.Model';
import { UserHelpDeskService } from '../Services/user-help-desk.service';
import { Employee } from '../Models/Employee.Model';

@Component({
  selector: 'app-user-help-desk',
  templateUrl: './user-help-desk.component.html',
  styleUrls: ['./user-help-desk.component.css'],
  providers:[UserHelpDeskService]
 
})
export class UserHelpDeskComponent implements OnInit {

  private employee:Employee;
  private ticket:Ticket;
  
  constructor(public route : Router,private UserHelpDeskService:UserHelpDeskService) 
  {
    this.employee = new Employee();
    this.ticket = new Ticket();
  }


   userDesk_form : FormGroup
 


  ngOnInit() 
  {
    this.userDesk_form = new FormGroup
    ({
      employeeId : new FormControl(null,[Validators.required,Validators.pattern('[0-9]*'),Validators.minLength(1),Validators.maxLength(6)]),
      comments : new FormControl(null,[Validators.required,Validators.pattern('^[a-zA-Z \-\']+'),Validators.maxLength(200)])
    })
  }

  complaintRaised()
  {
    this.employee.empId=2;
    this.employee.name="Sameer Mandavia";
    this.employee.capgeminiId=183381;
    this.employee.gender="Male";
    this.employee.email="sameer@gmail.com";
     this.employee.password="sameer";
     this.employee.wallet=1000;
     this.employee.subscriptionDate="2019-10-20"

    this.ticket.employee = this.employee;
    this.ticket.query = this.userDesk_form.value.comments;

      console.log("==========")
    this.UserHelpDeskService.complaintRaised(this.ticket).subscribe
    (
      (ticket)=>
      {
        console.log(ticket);
        
      }
    )


    alert("Ticket raised Successfully");
     this.route.navigate(['/ticket'])    // it will displayed to the admin
  }



}
