import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserHelpDeskService } from '../Services/user-help-desk.service';

@Component({
  selector: 'app-user-desk',
  templateUrl: './user-desk.component.html',
  styleUrls: ['./user-desk.component.css'],
  providers:[UserHelpDeskService]
})
export class UserDeskComponent implements OnInit {

  // userDesk_form : FormGroup

  constructor(public route : Router) { }

  ngOnInit() {

    // this.userDesk_form = new FormGroup
    // ({
    //   orderId : new FormControl(null,[Validators.required,Validators.pattern('[0-9]*')]),
    //   comments : new FormControl(null,[Validators.required,Validators.pattern('^[a-zA-Z \-\']+')])
    // })
  }


  userRaiseTicket()
  {
      this.route.navigate(['/RaisedQuery'])
  }

}
