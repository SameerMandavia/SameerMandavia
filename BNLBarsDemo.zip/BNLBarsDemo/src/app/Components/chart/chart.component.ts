import { Component, OnInit } from '@angular/core';
import * as d3 from 'd3';

@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.css'],
})
export class ChartComponent implements OnInit {
  private svg;
  private margin = 50;
  private width = 750 - this.margin * 2;
  private height = 500 - this.margin * 2;
  

  ngOnInit(): void {
    this.createSvg();
    this.drawBars(this.data);
  }

  private data = [
    {"Framework": "Vue", "Votes": "643","Color":"#41B883"},
    {"Framework": "React", "Votes": "293","Color":"#00D8FF"},
    {"Framework": "Angular", "Votes": "942","Color":"#DD0330"}
  ];

  private createSvg(): void {
    this.svg = d3
      .select('figure#bar')
      .append('svg')
      .attr('width', this.width + this.margin * 2)
      .attr('height', this.height + this.margin * 2)
      .append('g')
      .attr('transform', 'translate(' + this.margin + ',' + this.margin + ')');
      
  }

  private drawBars(data: any[]): void {
    // Create the X-axis band scale
    const x = d3
      .scaleBand()
      .range([0, this.width])
      .domain(data.map((display) => display.Framework))
      .padding(0.5);
      

    // Draw the X-axis on the DOM
    this.svg
      .append('g')
      .attr('transform', 'translate(0,' + this.height + ')')
      .call(d3.axisBottom(x))
      //To remove x axis line and tick from x axis
      .selectAll('.domain, .tick line').remove();
      
    
      

    // Create the Y-axis band scale
    const y = d3.scaleLinear().domain([0, 1000]).range([this.height, 0]);

    // Draw the Y-axis on the DOM
    //this.svg.append('g').call(d3.axisLeft(y));

    // Create and fill the bars
    this.svg
      .selectAll('bars')
      .data(data)
      .enter()
      .append('rect')
      .attr('x', (display) => x(display.Framework))
      .attr('y', (display) => y(display.Votes))
      .attr('width', x.bandwidth())
      .attr('height', (display) => this.height - y(display.Votes))
      .attr('fill', (display)=> (display.Color));

    
 
  }
}
