import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ChartComponent } from './Components/chart/chart.component';

const routes: Routes = [
  {path:'' ,pathMatch:'full',redirectTo:'charts'},
  {path:'charts',component:ChartComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
