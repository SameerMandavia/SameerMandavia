import { Component, OnInit, ViewChild, ElementRef, Input } from '@angular/core';
import * as d3 from 'd3';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {


  ngOnInit(): void {
   // this.generateData();//generate random data
   // this.createBar();//On the basis of data it will display bars.
  }
  title = 'BnlBars';

//   @ViewChild('bar') private barContainer : ElementRef;
//   @Input() data : Array<any>;
//   private margin: any = { top: 20, bottom: 20, left: 20, right: 20};
//   private bar: any;
//   private width: number;
//   private height: number;
//   private xScale: any;
//   private yScale: any;
//   private xAxis : any;
//   private yAxis : any;

//   chartData: any[];

//   generateData() {
//     this.chartData = [];
//     for (let i = 0; i < (5 + Math.floor(Math.random() * 10)); i++) {
//     console.log(this.chartData.push([`Index ${i}`,Math.floor(Math.random() * 100)
//     ]));
//    }
//  }

//   constructor() { }

//   createBar(){
//     let element = this.barContainer.nativeElement;
//     this.width = element.offSetWidth - this.margin.left - this.margin.right;
//     this.height = element.offSetHeight - this.margin.top - this.margin.bottom;

//     let svg = d3.select(element).append('svg')
//       .attr('class','bars')
//       .attr('transform',`translate(${this.margin.left},${this.margin.top})`);

//     // defines 2 domains x and y
//     let xDomain = this.data.map(first => first[0]);
//     let yDomain = [0,d3.max(this.data,first => first[1])];

//     // create scales
//     this.xScale = d3.scaleBand().padding(0.1).domain(xDomain).rangeRound([0, this.width]);
//     this.yScale = d3.scaleLinear().domain(yDomain).range([this.height, 0]);

//     this.xAxis = svg.append('g')
//     .attr('class','axis axis-x')
//     .attr('transform',`translate(${this.margin.left},${this.margin.top + this.height})`)
//     .call(d3.axisBottom(this.xScale));

//     this.yAxis = svg.append('g')
//     .attr('class','axis axis-y')
//     .attr('transform',`translate(${this.margin.left},${this.margin.top})`)
//     .call(d3.axisLeft(this.yScale));

//   }

}
